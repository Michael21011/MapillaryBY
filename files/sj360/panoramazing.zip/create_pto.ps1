Get-ChildItem ".\source" -Filter *.jpg | 
Foreach-Object {
    (Get-Content .\360_template.pto ).Replace('%filename%',$_.FullName) | Out-File .\output\$_.pto -Encoding ASCII
    $content = Get-Content $_.FullName
}

